import sqlite3 
##таблица queue - это айдишники тех, кто в очереди на чат
##таблица chats - это айдишники тех, кто общается
class database:
    def __init__(self, database_file):
        self.connection = sqlite3.connect(database_file, check_same_thread = False) 
        self.cursor = self.connection.cursor() #курсор, который отправляет наши запросы в БД 

    def addToqueue(self, chatId): #функция, которая добавляет айдишники тех, кто хочет встать в очередь
        with self.connection:
            return self.cursor.execute("INSERT INTO `queue` (`chat_id`) VALUES (?)", (chatId,))  

    def deleteFromqueue(self, chatId): #функция, которая удаляет айдишники, если пользователь нажал "отмена поиска" или нашел чат
        with self.connection: 
            return self.cursor.execute("DELETE FROM `queue` WHERE `chat_id` = ?", (chatId,)) 

    def deleteChat(self, chatId): #удаляем чат по его айди
        with self.connection:
            return self.cursor.execute("DELETE FROM `chats` WHERE `id` = ?", (chatId,)) 

    def takeGuy(self): #берём человека, который первый находится в очереди
        with self.connection:
            chat = self.cursor.execute("SELECT * FROM `queue`", ()).fetchmany(1)
            if (bool(len(chat))):
                for i in chat:
                    return i[1] #нам нужен только один человек
            else:
                return False #на случай если никого не будет

    def makeChat(self, chatOne, ChatSecond):
        with self.connection:
            if ChatSecond != 0: #все нашлось, удаляем из очереди и добавляем в чат
                self.cursor.execute("DELETE FROM `queue` WHERE `chat_id` = ?", (ChatSecond,))
                self.cursor.execute("INSERT INTO 'chats' (`chat_one`, `chat_two`) VALUES (?, ?)", (chatOne, ChatSecond,))
                return True
            
            else:
                return False

    def active(self, id): #чтобы мы могли найти нас и мы кого-то, нужная для получения\отправки сообщения
        with self.connection:
            chat = self.cursor.execute("SELECT * FROM `chats` WHERE `chat_one` = ?", (id,)) 
            idChat = 0
            for i in chat: #если ищем мы
                idChat = i[0]
                info = [i[0], i[2]] #если мы в chat_one, передаём айди собеседника

                
            if idChat == 0: 
                chat = self.cursor.execute("SELECT * FROM `chats` WHERE `chat_two` = ?", (id,)) #если ищут нас
                for i in chat:
                    idChat = i[0]
                    info = [i[0], i[1]]
                if idChat == 0: #ничего не нашлось, чата нет
                    return False 
                else:
                    return info
            else:
                return info
                


