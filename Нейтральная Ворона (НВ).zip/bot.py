import telebot
import random
from telebot import types #для кнопок
from database import database #мой авторский модуль и класс
from bs4 import BeautifulSoup as take #парсинг погоды на модуле красивое мыло4
import requests 

raven = telebot.TeleBot('5211223088:AAH6QST6kaB0VJjolh_oWSAkhIJUeN7CONc') #бот появился на свет
data = database('db.db') #подключаю БД


def moscowWheather(): #погода в москве
  moscow = requests.get('https://world-weather.ru/pogoda/russia/moscow/') #даю сайт
  code = take(moscow.text, 'html.parser') #получаю код
  temp = code.select('#weather-now-number')#указываю название класса или айдишника в css
  for i in temp:
    moscow=i.getText().strip() #получаю текст
    return moscow #нужная мне информация


def spbWheather(): #погода в питере
  peter = requests.get('https://world-weather.ru/pogoda/russia/saint_petersburg/') #даю сайт
  code = take(peter.text, 'html.parser') #получаю код
  temp = code.select('#weather-now-number')#указываю название класса или айдишника в css
  for i in temp:
    peter=i.getText().strip() #получаю текст
    return peter #нужная мне информация

def getJokeRoad(): #анекдотошная
    typeofjokes=requests.get('https://nekdo.ru/random/')#получение html - страницы
    htmlCode=take(typeofjokes.text, "html.parser") #получаю код
    jokes=htmlCode.select('.text') #указываю название класса или айдишника в css
    for i in jokes:        
        typeofjokes=i.getText().strip() #получаю текст
    return typeofjokes #нужная мне информация

@raven.message_handler(commands=['start']) #стартовское меню с приветсвием 
def start(message):

  #Массив рядов кнопок, каждый из которых является массивом объектов KeyboardButton, resizeKeyboard = True - подогнать высоту под колличество кнопок
  mark = types.ReplyKeyboardMarkup(resize_keyboard=True) 

  firstButton = types.KeyboardButton('⭐ Найти собеседника') #создал кнопку и дал ей название
  SecondButton = types.KeyboardButton('📚 Анекдот?')
  ThirdButton = types.KeyboardButton('☁ Погода?')
  mark.add(firstButton, SecondButton, ThirdButton) #добавляю кнопки, чтобы они были видны
  raven.send_message(message.chat.id, 'Добро пожаловать в Нейтральную Ворону,  {0.first_name}!  🌙\n\nМесто, где вы можете анонимно общаться на любые темы, не боясь осуждения, и не бояться, что ваше мнение "непопулярно".\nСбросьте стресс. Поговорите!\n\nС полным сохранением анонимности. 🔒'.format(message.from_user), reply_markup = mark) #обращение по нику в тг

@raven.message_handler(commands=['menu']) #меню
def menu(message):
  mark = types.ReplyKeyboardMarkup(resize_keyboard=True)
  firstButton = types.KeyboardButton('⭐ Найти собеседника')
  SecondButton = types.KeyboardButton('📚 Анекдот?')
  ThirdButton = types.KeyboardButton('☁ Погода?')
  mark.add(firstButton, SecondButton, ThirdButton)
  raven.send_message(message.chat.id, 'Выбирай :)'.format(message.from_user), reply_markup = mark)  

@raven.message_handler(commands=['stop']) #останавливаем беседу
def stop(message): #функция остановки нашего чата
  info =  data.active(message.chat.id) #данные активного чата
  if info != False: 
    data.deleteChat(info[0]) #передаём айди активного чата
    mark = types.ReplyKeyboardMarkup(resize_keyboard=True) 
    firstButton = types.KeyboardButton('⭐ Найти собеседника')
    SecondButton = types.KeyboardButton('📚 Анекдот?')
    ThirdButton = types.KeyboardButton('☁ Погода?')
    mark.add(firstButton, SecondButton, ThirdButton)
    raven.send_message(info[1], '✖ Собеседник покинул чат', reply_markup=mark) #если закончили общаться не по своей воле
    raven.send_message(message.chat.id, '✖ Беседа окончена', reply_markup=mark)

@raven.message_handler(content_types=['text']) #Самое главное     
def bot_message(message):
  if message.chat.type == 'private':
    if message.text == '📚 Анекдот?': 
      raven.send_message(message.from_user.id, getJokeRoad()) #вызов функции анекдота
    elif message.text == '☁ Погода?': #парсинг погоды с подменю
        mark = types.ReplyKeyboardMarkup(resize_keyboard=True)
        firstButton = types.KeyboardButton('Москва 🍺')
        SecondButton = types.KeyboardButton('Санкт-Петербург 🧂')
        ThirdButton = types.KeyboardButton('⏪ Назад')
        mark.add(firstButton, SecondButton, ThirdButton)
        raven.send_message(message.chat.id, '🔎 Где?', reply_markup = mark)
    elif message.text == 'Москва 🍺':
      raven.send_message(message.chat.id, f'В Москве сейчас {moscowWheather()} 🌡️\nКакая прекрасная погода!\nМарток? Надевай сто порток.  ')
      mark = types.ReplyKeyboardMarkup(resize_keyboard=True)
      firstButton = types.KeyboardButton('⏪ Назад')
      mark.add(firstButton)    
    elif message.text == 'Санкт-Петербург 🧂':
      raven.send_message(message.chat.id, f'В Питере сейчас {spbWheather()} 🌡️\nСмотри, чтобы в море не унесло\nМарток? Надевай сто порток.  ')
      mark = types.ReplyKeyboardMarkup(resize_keyboard=True)
      firstButton = types.KeyboardButton('⏪ Назад')
      mark.add(firstButton)  
    elif message.text == '⏪ Назад': #кнопка назад - возвращение в меню
      mark = types.ReplyKeyboardMarkup(resize_keyboard=True)
      firstButton = types.KeyboardButton('⭐ Найти собеседника')
      SecondButton = types.KeyboardButton('📚 Анекдот?')
      ThirdButton = types.KeyboardButton('☁ Погода?')
      mark.add(firstButton, SecondButton, ThirdButton)
      raven.send_message(message.chat.id, '📝 Чего желаете?', reply_markup = mark)
    elif message.text == '⭐ Найти собеседника': 
      mark = types.ReplyKeyboardMarkup(resize_keyboard=True)
      firstButton = types.KeyboardButton('❌ Прекратить поиск')
      SecondButton = types.KeyboardButton('🍀 Пожелать удачи')
      mark.add(firstButton, SecondButton)
      chatSec = data.takeGuy() 
      if data.makeChat(message.chat.id, chatSec) == False: #если чат не создался
        data.addToqueue(message.chat.id) #добавляем в очередь
        raven.send_message(message.chat.id, '🔎 Ищем тебе собеседника...', reply_markup = mark)
      elif data.makeChat(message.chat.id, chatSec) == True: #если нашлись два собеседника
        letsGo = "Собеседник найден. Приятного общения!\nЧтобы завершить беседу, тыкай /stop"
        mark = types.ReplyKeyboardMarkup(resize_keyboard=True)
        firstButton = types.KeyboardButton('/stop')
        mark.add(firstButton)
        raven.send_message(message.chat.id, letsGo, reply_markup=mark) #сообщение для меня
        raven.send_message(chatSec, letsGo, reply_markup=mark) #сообщение для него    
    elif message.text == '❌ Прекратить поиск': #если мы передумали
        data.deleteFromqueue(message.chat.id) #убираем id пользователя из списка ожидания
        mark = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item1 = types.KeyboardButton('⏪ Назад')
        mark.add(item1)
        raven.send_message(message.chat.id, 'Вы остановили поиск.'.format(message.from_user), reply_markup = mark)
    elif message.text == '🍀 Пожелать удачи':
      raven.send_message(message.chat.id, 'Удачи, дружище!')
    elif data.active(message.chat.id) != False: 
        info = data.active(message.chat.id) 
        raven.send_message(info[1], message.text)#отправка сообщений между пользователями 
    else: #ответ на несуществующие команды
      diologue = random.randint(1,5)
      if diologue == 1:
         raven.send_message(message.chat.id, 'Да что ты, чёрт побери, такое несешь?!')    
      elif diologue == 2:
         raven.send_message(message.chat.id, 'Эрен, ты меня пугаешь! О чём ты?')
      elif diologue == 3:
         raven.send_message(message.chat.id, 'Russian, m******er! Do you speak it?')
      elif diologue == 4:
         raven.send_message(message.chat.id, 'Напиши чертову команду, Синдзи')
      elif diologue == 5:
         raven.send_message(message.chat.id, 'Я создам идеальное общество, создам такой чат, в котором люди будут писать команды!')
@raven.message_handler(content_types='sticker') #возможность отправлять стикеры
def stickers(message):
  if message.chat.type == 'private':
    if data.active(message.chat.id) != False:
      info = data.active(message.chat.id)
      raven.send_sticker(info[1], message.sticker.file_id)
    else:
      raven.send_message(message.chat.id, 'Крутые стикеры, бро!\nА как насчёт показать им кому-то в анонимном чате?')
@raven.message_handler(content_types='voice') #возможность отправлять голосовые
def voices(message):
  if message.chat.type == 'private':
    if data.active(message.chat.id) != False:
      info = data.active(message.chat.id)
      raven.send_voice(info[1], message.voice.file_id)
    else:
      raven.send_message(message.chat.id, 'Какой нежный и бархатный голос, какой прекрасный боевой дух!\nА как насчёт отправить голосовое в анонимном чате?')
      

raven.polling(non_stop=True) #штука, чтобы бот работал, зацикливаем
